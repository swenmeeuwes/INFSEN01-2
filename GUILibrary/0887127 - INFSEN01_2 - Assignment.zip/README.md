# INFSEN01-2
Assignments for the course "INFSEN01-2"

# Student
Swen Meeuwes
0887127
