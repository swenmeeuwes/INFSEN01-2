﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUILibrary.Input
{
    enum ButtonState
    {
        RELEASED = 0,
        PRESSED = 1
    }
}
