﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUILibrary.Input.Model
{
    class Key
    {
        public int KeyCode { get; set; }
        public string KeyName { get; set; }
    }
}
