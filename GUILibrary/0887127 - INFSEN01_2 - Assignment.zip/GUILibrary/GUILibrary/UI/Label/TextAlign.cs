﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUILibrary.UI.Label
{
    enum TextAlign
    {
        LEFT = 0,
        RIGHT = 1,
        CENTER = 2,
        TOP = 3,
        BOTTOM = 6,
        MIDDLE = 9
    }
}
